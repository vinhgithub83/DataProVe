Example 9b in the manual on data forwarding/transfering
=> Violation of the DPR conformance relation 