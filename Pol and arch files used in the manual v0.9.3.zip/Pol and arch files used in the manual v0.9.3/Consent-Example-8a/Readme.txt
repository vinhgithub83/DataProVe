Under Section "Examples with cryptographic functions" in the user manual.
  - Example 8/a (Collection policy, collection consent)


