Example 9a in the manual on data forwarding/transfering
=> DPR conformance case