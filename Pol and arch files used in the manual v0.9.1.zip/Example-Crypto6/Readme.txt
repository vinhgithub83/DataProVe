Under Section "Examples with cryptographic functions" in the user manual.
  - Example 6 (2-layer nested crypto function application) 


